Flappy Tap — offline web build (v2.0.0-complete)
Windows: double-click PLAY-WINDOWS.bat (or open index.html in Chrome/Edge)
Android: open the GitHub Pages link in Chrome (Add to Home Screen for PWA)
Controls: tap / click / Space to flap
Modes: Classic / Daily Challenge / Practice · Combo x2 at 5 · Skins + medals
