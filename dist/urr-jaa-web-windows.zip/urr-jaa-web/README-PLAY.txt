Urr Jaa! — offline web build (v3.0.0-urrjaa)
Windows: double-click PLAY-WINDOWS.bat (or open index.html in Chrome/Edge)
Android: open the GitHub Pages link in Chrome (Add to Home Screen for PWA)
Controls: tap / click / Space to flap — NO countdown
Modes: Classic / Daily / Practice / Challenge 100m / Hard / Reverse / Giant
Garage: birds, vehicles, Pakistani cities, weather, hats, trails · coins & missions
Repo folder: flappy-tap (OfferPk/flappy-tap) · title Urr Jaa!
