Urr Jaa! — offline web build (v3.2.0-urrjaa)
Windows: double-click PLAY-WINDOWS.bat (or open index.html in Chrome/Edge)
Android: open the GitHub Pages link in Chrome (Add to Home Screen for PWA)
Controls: tap / click / Space to flap — NO countdown
Modes: Classic / Time Attack / Hard / No Coin / Challenge Stages / One Life
Garage: birds, vehicles, accessories, trails, areas · streak · boards · juice
Repo folder: flappy-tap (OfferPk/flappy-tap) · title Urr Jaa!
