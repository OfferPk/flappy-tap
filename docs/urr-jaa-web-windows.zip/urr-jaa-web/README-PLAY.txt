Urr Jaa! — offline web build (v3.58.2-urrjaa)
Quick guide: open how-to-play.html (English / Roman Urdu)
Windows: double-click PLAY-WINDOWS.bat (or open index.html in Chrome/Edge)
Android: open the GitHub Pages link in Chrome (Add to Home Screen for PWA)
Controls: tap / click / Space to flap — NO countdown
Modes: Classic / Time Attack / Hard / No Coin / Challenge Stages / One Life
Garage: birds, vehicles, accessories, trails, areas · streak · boards · juice
Mystery Rewards: 10 gifts = 1 spin · wheel 444–999 coins
Repo folder: flappy-tap (OfferPk/flappy-tap) · title Urr Jaa!
