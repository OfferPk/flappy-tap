Flappy Tap — offline web build (v1.1 physics + medals)
Windows: double-click PLAY-WINDOWS.bat (or open index.html in Chrome/Edge)
Android: open the GitHub Pages link in Chrome (Add to Home Screen for PWA)
Controls: tap / click / Space to flap
Skins: Bird / Bike / Rickshaw · Medals at 10 / 25 / 50 (saved locally)
